Students:
Dustin Bolink (V00747883)
Konrad Schultz (V00761540)

Files Edited:
- SparkJava8Examples_post
    - /src
        - MovielensAvg.java
        - MovielensAvgCombiner.java
        - MovielensAvgMapper.java
        - MovielensAvgReducer.java
        - MovielensGenreAvg.java
        - MovielensGenreAvgCombiner.java
        - MovielensGenreAvgMapper.java
        - MovielensGenreAvgReducer.java
- hadoop_examples_post
    - /src
        - SparkMovielensAvg.java
        - SparkMovielensGenresAvg.java


Output Files: 
- SparkJava8Examples_post
    - /output_movielens (1)
    - /output_movielens_genres (2)
- hadoop_examples_post
    - /output_movielens (3)
    - /output_movielens_genres (4)
